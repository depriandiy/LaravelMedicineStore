-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2022 at 10:01 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_medicine`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Analgesik Non Narkotik', '', NULL, NULL),
(2, 'Nyeri Neuropatik', '', NULL, NULL),
(3, 'Anestetik Lokal', '', NULL, NULL),
(4, 'Anestetik Umum dan Oksigen', '', NULL, NULL),
(5, 'Obat untuk Prosedur Pre Operatif', '', NULL, NULL),
(6, 'Antialergi dan Obat untuk Anafilaksis', '', NULL, NULL),
(7, 'Antelmintik', 'Antelmintik Intestinal', NULL, NULL),
(8, 'Antiseptik Saluran Kemih', '', NULL, NULL),
(9, 'Antiinfeksi Khusus', 'Antilepra', NULL, NULL),
(10, 'Antibakteri', 'Beta Laktam', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(11, '2022_02_28_031102_create_products_table', 2),
(12, '2022_02_28_031211_create_categories_table', 2),
(13, '2022_02_28_032257_alter_products_table', 2),
(14, '2022_02_28_032550_alter_categories_table', 2),
(15, '2022_02_28_033441_addforeign_products_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `generic_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `form` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `restriction_formula` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `faskes_tk_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `faskes_tk_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `faskes_tk_3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `generic_name`, `form`, `restriction_formula`, `description`, `faskes_tk_1`, `faskes_tk_2`, `faskes_tk_3`, `created_at`, `updated_at`, `category_id`) VALUES
(1, 'Asam Mefenamat', 'kaps 500 mg', '30 kaps/bulan', '-', 'ya', 'ya', 'ya', NULL, NULL, 1),
(2, 'Ibuprofen', 'tab 200/400 mg', '30 tab/bulan', '-', 'ya', 'ya', 'ya', NULL, NULL, 1),
(3, 'Ketoprofen', 'sup 100 mg', '2 sup/hari, maks 3 hari', 'Untuk nyeri sedang sampai berat pada pasien yang tidak dapat menggunakan Analgesik secara oral', 'tidak', 'ya', 'ya', NULL, NULL, 1),
(4, 'Gabapentin', 'kaps 100 mg', '60 kaps/bulan', 'Hanya untuk neuralgia pascaherpes atau nyeri neuropati diabektium', 'tidak', 'ya', 'ya', NULL, NULL, 2),
(5, 'Amitriptilin', 'tab 25 mg', '30 tab/bulan', '-', 'ya', 'ya', 'ya', NULL, NULL, 2),
(6, 'Karbamazepin', 'tab 100 mg', '60 tab/bulan', 'Hanya untuk neuralgia trigeminal', 'ya', 'ya', 'ya', NULL, NULL, 2),
(7, 'Bupivakain Heavy', 'inj 0,5% + glukosa 8%', '-', 'Khusus untuk analgesia spinal', 'tidak', 'ya', 'ya', NULL, NULL, 3),
(8, 'Etil Klorida', 'spray 100 mL', '-', '-', 'ya', 'ya', 'ya', NULL, NULL, 3),
(9, 'Lidokain', 'spray topikal 10%', '-', '-', 'ya', 'ya', 'ya', NULL, NULL, 3),
(10, 'Deksmedetomidin', 'inj 100mcg/mL', '-', 'Untuk sedasi pada pasien ICU, kraniotomi, bedah jantung dan operasi yang butuh waktu pembedahan yg lama', 'tidak', 'ya', 'ya', NULL, NULL, 4),
(11, 'Desfluran', 'ih', '-', '-', 'tidak', 'ya', 'ya', NULL, NULL, 4),
(12, 'Halotan', 'ih', '-', 'Tidak boleh digunakan berulang dan tidak untuk pasien gangguan fungsi hati', 'tidak', 'ya', 'ya', NULL, NULL, 4),
(13, 'Atropin', 'inj 0,25 mg/mL (i.v./s.k.)', '-', '-', 'ya', 'ya', 'ya', NULL, NULL, 5),
(14, 'Diazepam', 'inj 5 mg/mL', '-', '-', 'ya', 'ya', 'ya', NULL, NULL, 5),
(15, 'Midazolam', 'inj 5 mg/mL (i.v.)', 'Dosis rumatan: 1 mg/jam, Dosis premedikasi: 8 vial/kasus', 'Untuk premedikasi sebelum induksi anestesi dan rumatan selama anestesi umum', 'tidak', 'ya', 'ya', NULL, NULL, 5),
(16, 'Deksametason', 'inj 5 mg/mL', '20 mg/hari', '-', 'ya', 'ya', 'ya', NULL, NULL, 6),
(17, 'Difenhidramin', 'inj 10 mg/mL (i.v./i.m.)', '30 mg/hari', '-', 'ya', 'ya', 'ya', NULL, NULL, 6),
(18, 'Klorfeniramin', 'tab 4 mg', '3 tab/hari, maks 5 hari', '-', 'ya', 'ya', 'ya', NULL, NULL, 6),
(19, 'Albendazol', 'susp 200 mg/5 mL', '-', '-', 'ya', 'ya', 'ya', NULL, NULL, 7),
(20, 'Mebendazol', 'sir 100 mg/5 mL', '-', '-', 'ya', 'ya', 'ya', NULL, NULL, 7),
(21, 'Pirantel Pamoat', 'tab 250 mg', '-', '-', 'ya', 'ya', 'ya', NULL, NULL, 7),
(22, 'Dapson', 'tab 100 mg', '-', '-', 'ya', 'ya', 'ya', NULL, NULL, 8),
(23, 'Klofazimin', 'kaps dalam minyak 100 mg', '-', '-', 'ya', 'ya', 'ya', NULL, NULL, 8),
(24, 'Rifampisin', 'tab 450 mg', '-', '-', 'tidak', 'ya', 'ya', NULL, NULL, 8),
(25, 'Asam Pipemidat', 'kaps 400 mg', '29 kaps/kasus', '-', 'tidak', 'ya', 'ya', NULL, NULL, 9),
(26, 'Metenamin Mandelat', 'tab sal enterik 500 mg', '-', '-', 'ya', 'ya', 'ya', NULL, NULL, 9),
(27, 'Nitrofurantoin', 'tab 50 mg', '-', '-', 'tidak', 'ya', 'ya', NULL, NULL, 9),
(28, 'Amoksisilin', 'tab 500 mg', '10 hari', '-', 'ya', 'ya', 'ya', NULL, NULL, 10),
(29, 'Benzatin Benzilpenisilin', 'inj 1,2 juta IU/mL (i.m.)', '10 hari', '-', 'ya', 'ya', 'ya', NULL, NULL, 10),
(30, 'Ampisilin', 'inj 250 mg (i.m./i.v.)', '10 hari', '-', 'ya', 'ya', 'ya', NULL, NULL, 10);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_id_foreign` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
